#Assignment 1
Harrison Kiang

hkiang2

##How to Run
- Open Rstudio
- In Rstudio, open "assignment1.Rproj"
- Install dependent packages in Tools -> Install Packages...
- Select all text in a.R, etc.
- Click "Run"

