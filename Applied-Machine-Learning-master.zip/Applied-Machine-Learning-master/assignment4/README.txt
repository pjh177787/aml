To run project:

R files:
Open RStudio.
setwd('/directory/of/project')
source('project_file.R')

MATLAB files (used for 3.7):
Open MATLAB
load "wdbc.m" to workspace
run program
program will take data from csv files in breast_results directory

3.4
Source code: “hw4_3_4.R”
  Libraries: "latice", "caret", "chemometrics", "plsdepot"
  Run source code hw4_3_4.R in RStudio
  Install missing packages from Tools → Install Packages...


3.5
Source code: “p2.R”
	Libraries: “mixOmics” for nipals
	Run source code p2.R in RStudio
	Install missing packages from Tools → Install Packages...
	Notes: Credit to Matti Pastell for stem plot algorithm http://www.r-bloggers.com/matlab-style-stem-plot-with-r/ 
	
3.7
Source code: “3-7.R”, "wdbc.m"
  Libraries: "mixOmics", "caret", "plot3Drgl", "plsdepot"
  Run source code 3-7.R in RStudio
  Install missing packages from Tools → Install Packages...
  Run source code wdbc.m in MATLAB

                        _,-' - `--._
                      ,'.:  __' _..-)
                    ,'     /,o)'  ,'
                   ;.    ,'`-' _,)
                 ,'   :.   _.-','
               ,' .  .    (   /
              ; .:'     .. `-/
            ,'       ;     ,'
         _,/ .   ,      .,' ,
       ,','     .  .  . .\,'..__
     ,','  .:.      ' ,\ `\)``
     `-\_..---``````-'-.`.:`._/
     ,'   '` .` ,`- -.  ) `--..`-..
     `-...__________..-'-.._  \
        ``--------..`-._ ```
                     ``    Hi I am a frog.
